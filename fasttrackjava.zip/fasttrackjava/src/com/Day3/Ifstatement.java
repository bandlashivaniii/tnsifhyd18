package com.Day3;

public class Ifstatement {
	public static void main(String[] args) {

		int x = 6;
		if (x !=6)
			System.out.println("Value of x is not 5");
		System.out.println("Value of x is 5");
	}

}
