package com.day4;

public class PetMain {
public static void main(String[] args) {
Pet p=new PetDerived();
p.test();
}
}
