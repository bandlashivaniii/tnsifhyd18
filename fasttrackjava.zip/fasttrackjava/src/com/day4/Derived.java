package com.day4;

public class Derived extends Base {
 void fun() {
	 System.out.println("Abstract Contents of derived class-Derived fun() called");
 }
}
