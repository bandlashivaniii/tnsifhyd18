package com.day4;

abstract class Base {
	abstract void fun();
}



