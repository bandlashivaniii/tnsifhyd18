package com.day4;
interface Pet{
		public void test();
	}


