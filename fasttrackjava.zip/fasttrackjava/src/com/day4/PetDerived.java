package com.day4;

public class PetDerived implements Pet{
public void test() {
	System.out.println("PetDerived contents called()");
}
}
