package com.day4;

public class BufferStr {
	public static void main(String args[]){  
		StringBuffer sb=new StringBuffer("Hello ");  
		sb.append("world");//now original string is changed  
		System.out.println(sb);//prints Hello Java  
		}  
		}  


