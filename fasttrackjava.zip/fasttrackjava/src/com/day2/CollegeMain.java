package com.day2;

public class CollegeMain {
public static void main(String[] args) {
	College c1=new College();
	System.out.println(c1.run());
}
}
