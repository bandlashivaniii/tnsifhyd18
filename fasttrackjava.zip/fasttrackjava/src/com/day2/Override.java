package com.day2;

public class Override {

	String display()
	{
		return "Instance content of class Override";
	}
	static void display1()
	{
		System.out.println("Static content of Override");
	}
}
