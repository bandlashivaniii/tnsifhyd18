/**
 * 
 */
/**
 * 
 */
module fasttrackjava {
}