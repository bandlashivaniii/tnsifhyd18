package com.day3;

public class ForLoopStatement {

	public static void main(String[] args) {
		

	}

}
