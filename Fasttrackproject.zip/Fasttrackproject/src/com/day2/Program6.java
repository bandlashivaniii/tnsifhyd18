package com.day2;
import java.math.BigDecimal;
import java.math.BigInteger;
//java scanner with BigInteger and BigDecimal
import java.util.Scanner;

public class Program6 {
	public static void main(String[] args) {
			Scanner input= new Scanner(System.in);
			System.out.println("enter a big integer:");
			BigInteger value1 = input.nextBigInteger();
			System.out.println("using nextBigIntegervalue():" +value1);
			System.out.println("enter a big decimal:");
			BigDecimal value2 = input.nextBigDecimal();
			System.out.print("using next Bigdecimal():" +value2);
			input.close();
	}

		}


