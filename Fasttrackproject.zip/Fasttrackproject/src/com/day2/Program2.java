package com.day2;
//java scanner nextInt()
import java.util.Scanner;

public class Program2 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter an integer");
		int data1 = input.nextInt();
		System.out.println("Using nextint():" +data1);
		input.close();
	}
}

