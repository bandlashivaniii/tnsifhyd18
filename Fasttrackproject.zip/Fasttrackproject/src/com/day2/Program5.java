package com.day2;
//java scanner nextLIne()
import java.util.Scanner;

public class Program5 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter your name");
		String value = input.nextLine();
		System.out.println("Using nextLine():" +value);
		input.close();
	}
}


