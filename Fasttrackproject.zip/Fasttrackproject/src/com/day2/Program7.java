package com.day2;

public class Program7 {
	//Addition operator
	public static void main(String[] args) {
		int i = 1 + 2;
		String s = "Hello" + "World";
		System.out.println(i);
		System.out.println(s);
		
// sub operator
     int x = 1;
     int y = 12 - x ;
     System.out.println(y);
     
 //mult operator
     int a = 1;
     int b = 12 * 2 ;
     System.out.println(b);
     
  //Div operator
     int c = 1;
     int d = 12 / 2 ;
     System.out.println(d);
     
   //modulus operator
     int mod = 13 % 2;
     System.out.println(mod);
     
   //increment operator
     int p = 10;
     System.out.println(p++);
     int k = 10;
     System.out.println(k++);
     
     // decrement operator
     int g = 10;
     System.out.println(g--);
     int n = 10;
     System.out.println(--n);
     
     //boolean
     boolean f;
     f = (5 < 4)?true:false;
     System.out.println(f);
	}
}
     
     
