package com.day2;
//java scanner next()
import java.util.Scanner;

public class Program4 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String value = input.next();
		System.out.println("Using next():" +value);
		input.close();	

}
}