package com.day1;

import java.util.Scanner;

public class Program12 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the first string:");
		String str1 = scanner.nextLine();
		System.out.println("Enter the second string:");
		String str2 = scanner.nextLine();
		String concatenatedString = str1 + str2;
		System.out.println("The concatenated stringis:" + concatenatedString);
		scanner.close();
		
	}
}



