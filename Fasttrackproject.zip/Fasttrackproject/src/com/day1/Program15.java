package com.day1;

import java.util.Scanner;

public class Program15 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number:");
		int n = scanner.nextInt();
		int sum = 0;
		for(int i = 1;i<=n;i++) {
			sum +=i;
			System.out.println("sum of natural numberup to " + n + "is:"+sum);
		}
		scanner.close();
	}
	}

