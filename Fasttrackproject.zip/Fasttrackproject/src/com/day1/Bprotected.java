package com.day1;

public class Bprotected {
	public static void main(String[] args) {
		Aprivate obj = new Aprivate();
		 obj.display();
	}
}

