package com.day1;

public class Program3 {
	public static void main(String[] args) {
		int num = 8;
		int factorial = 1;
		for(int i=1;i<=num;i++)
		{
			factorial*= i;
		}
		System.out.print("factorial of "+num+" is="+factorial);
	}
}

