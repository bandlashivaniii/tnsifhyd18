package com.day1;

public class Apublic {
	public void display()
	{
		System.out.println("TNS Sessions");
	}
}



