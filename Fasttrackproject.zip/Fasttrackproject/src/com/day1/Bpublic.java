package com.day1;

public class Bpublic {
	public static void main(String[] args) {
		Apublic obj = new Apublic();
		obj.display();
	}
}

