package com.day1;

public class Aprotected {
     protected void display()
		{
		System.out.println("TNS Sessions");
		}
}
