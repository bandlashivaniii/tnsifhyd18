package com.day1;

import java.util.Scanner;

public class Program11 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the first number:");
		double num1 = scanner.nextDouble();
		System.out.println("Enter the second number:");
		double num2 = scanner.nextDouble();
		double average = (num1 + num2)/2;
		System.out.println("The average of "+ num1 +"and" + num2 +"+average");
		scanner.close();
	
	}
}


