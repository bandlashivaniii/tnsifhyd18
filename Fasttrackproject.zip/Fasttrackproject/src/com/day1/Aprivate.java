package com.day1;

public class Aprivate {
	private void display()
	{
		System.out.println("TNS Sessions");
	}
}
