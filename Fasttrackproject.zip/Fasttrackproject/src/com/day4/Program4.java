package com.day4;

public class Program4 {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("hi");
			 sb.append("i'm akshya");
				System.out.println(sb);
	}
}
