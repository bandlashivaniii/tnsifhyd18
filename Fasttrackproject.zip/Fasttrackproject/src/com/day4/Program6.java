package com.day4;

public class Program6 {
	

}
