package com.day4;

public class Program3 {
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("Hello");
		sb.append("World");
		System.out.println(sb);
	}
}
